// Khai báo thư viện
using System;
// Khai báo không gian tên chứa Bài làm
namespace NMLT.Buoi1
{
    // Đơn thể chứa các phương thức
    class InChuoi
    {
        // Phương thức điểm vào chương trình
        public static void ChayBaiTap()  
        {
            // Xuất dữ liệu
            Console.WriteLine("Whoever is happy will make others happy too");
            Console.WriteLine("--Anne Frank");
            // Dừng chương trình chờ nhập phím
            Console.Read();
        }
    }
 }